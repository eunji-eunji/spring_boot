package com.example.oauth2.constant;

public enum Role {
    USER, ADMIN
}
