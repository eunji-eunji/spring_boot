package com.example.oauth2.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class MailDto {

    private String title;

    private String content;

    private String address;
}
