package com.example.oauth2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Oauth2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
