package com.example.demo.constant;

public enum Role {
    ADMIN, USER
}
